var express = require('express');
var router = express.Router();
var events = require('events')
var emitter = new events.EventEmitter();
var mysql=require("mysql");  

var EventEmitter = require('events').EventEmitter; 
var event = new EventEmitter(); 
event.on('some_event', function() { 
	console.log('some_event 事件触发'); 
}); 
setTimeout(function() { 
	event.emit('some_event'); 
}, 1000); 


// var name = req.query.username;
// if (name=='root') {
// 	emitter.emit("ok");
// }
// else{
// 	emitter.emit("false");
// }

router.post('/log', function(req, res, next) {
  //    创建数据库连接
    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"newpass",
        // port: '3306',
        database:"qqmusic"
    });

    var sess = req.session;


  emitter.on("ok",function(){
        return res.end("登陆成功");    //    向前台返回数据
  });

  emitter.on("false",function(){
        return res.end("登录失败");    //    向前台返回数据
  });
  console.log(req.body.username);
    //    连接数据库
    connection.connect();
    var sql="select * from user where number='"+req.body.username+"' and password='"+req.body.passwd+"'";    //    在数据库里面查询用户名跟密码
    connection.query(sql,function(err,result){    //    执行sql语句，并返回结果
      // if(result){
      //   console.log(result.length);
      //   console.log(result[0].name);
      // }
      
        if(err){
            // res.end("登录失败");    //    数据库错误
            emitter.emit("false");
            console.log(err);
        }
        if(result.length==0){
          // res.send(result);
          emitter.emit("false");
            // emitter.emit("false");    
            // res.end("用户名密码不正确");    //    数据库里面没找到配对的内容返回参数
        }else{
          // emitter.emit("ok");
          req.session.loginUser = result[0].name;
          console.log('logi:n'+req.session.loginUser);
          res.end(result[0].name);
            // res.end("登陆成功");    //返回登录成功
        }
    })
    connection.end();    //    关闭数据库
});



router.get('/album1', function(req, res, next) {
  //    创建数据库连接
    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"newpass",
        // port: '3306',
        database:"qqmusic"
    });

    emitter.on("ok",function(){
        return res.end("登陆成功");    //    向前台返回数据
    });

  emitter.on("false",function(){
        return res.end("登录失败");    //    向前台返回数据
  });

    connection.connect();
    if(req.query.Language==="全部"){
          var sql="select * from album";    //    在数据库里面查询用户名跟密码
    }else{
      console.log(req.query.Language);
      var sql = "select * from album where Album_language='"+req.query.Language+"'";    //    在数据库里面查询用户名跟密码

    }
    connection.query(sql,function(err,result){    //    执行sql语句，并返回结果

console.log(result.length);
        if(err){
            // res.end("登录失败");    //    数据库错误
            emitter.emit("false");
            console.log(err);
        }
        if(result.length==0){
          res.send(result);
          emitter.emit("false");
        }else{
          // res.end(result[]);
          res.send(result);
            // res.end("登陆成功");    //返回登录成功
        }
    })
    connection.end();    //    关闭数据库



});

router.get('/album2', function(req, res, next) {
  //    创建数据库连接
    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"newpass",
        // port: '3306',
        database:"qqmusic"
    });

    emitter.on("ok",function(){
        return res.end("登陆成功");    //    向前台返回数据
    });

  emitter.on("false",function(){
        return res.end("没有");    //    向前台返回数据
  });

    connection.connect();
    console.log(req.query.Language);
    console.log(req.query.Genre);
    console.log(req.query.Language==="全部");
    if(req.query.Language==="全部"){
      var sql = "select * from album where Album_genre='"+req.query.Genre+"'";
    }
    else{
    var sql="select * from album where Album_language='"+req.query.Language+"' and Album_genre='"+req.query.Genre+"'";    //    在数据库里面查询用户名跟密码
  }
    // if(req.query.Language==="全部"){
    //       var sql="select * from album";    //    在数据库里面查询用户名跟密码

    //   // var sql="select * from album where Album_name='80/90年代迪斯科舞曲精选集'";    //    在数据库里面查询用户名跟密码
    // }
    connection.query(sql,function(err,result){    //    执行sql语句，并返回结果

console.log(result.length);
        if(err){
            // res.end("登录失败");    //    数据库错误
            emitter.emit("false");
            console.log(err);
        }
        if(result.length==0){
          res.send(result);
          emitter.emit("false");
        }else{
          // res.end(result[]);
          res.send(result);
            // res.end("登陆成功");    //返回登录成功
        }
    })
    connection.end();    //    关闭数据库



});


router.get('/singer1', function(req, res, next) {
  //    创建数据库连接
    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"newpass",
        // port: '3306',
        database:"qqmusic"
    });

    emitter.on("ok",function(){
        return res.end("登陆成功");    //    向前台返回数据
    });

  emitter.on("false",function(){
        return res.end("登录失败");    //    向前台返回数据
  });

    connection.connect();
    if(req.query.area==="全部"){
          var sql="select * from singer";    //    在数据库里面查询用户名跟密码
    }else{
      console.log(req.query.area);
      var sql = "select * from singer where Singer_area='"+req.query.area+"'";    //    在数据库里面查询用户名跟密码

    }

    connection.query(sql,function(err,result){    //    执行sql语句，并返回结果

    console.log(result.length);
        if(err){
            // res.end("登录失败");    //    数据库错误
            emitter.emit("false");
            console.log(err);
        }
        if(result.length==0){
          res.send(result);
          emitter.emit("false");
        }else{
          // res.end(result[]);
          res.send(result);
            // res.end("登陆成功");    //返回登录成功
        }
    })
    connection.end();    //    关闭数据库



});

router.get('/singer2', function(req, res, next) {
  //    创建数据库连接
    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"newpass",
        // port: '3306',
        database:"qqmusic"
    });

    emitter.on("ok",function(){
        return res.end("登陆成功");    //    向前台返回数据
    });

  emitter.on("false",function(){
        return res.end("没有");    //    向前台返回数据
  });

    connection.connect();
    // console.log(req.query.Language);
    // console.log(req.query.Genre);
    // console.log(req.query.Language==="全部");
    if(req.query.area==="全部"){
      if(req.query.first==="All"){
        var sql = "select * from singer";
      }
      else{
        var sql = "select * from singer where Singer_first='"+req.query.first+"'";
      }
    }
    else{
    var sql="select * from singer where Singer_area='"+req.query.area+"' and Singer_first='"+req.query.first+"'";    //    在数据库里面查询用户名跟密码
  }
    // if(req.query.Language==="全部"){
    //       var sql="select * from album";    //    在数据库里面查询用户名跟密码

    //   // var sql="select * from album where Album_name='80/90年代迪斯科舞曲精选集'";    //    在数据库里面查询用户名跟密码
    // }
    connection.query(sql,function(err,result){    //    执行sql语句，并返回结果

console.log(result.length);
console.log("lalala"+req.query.first);
        if(err){
            // res.end("登录失败");    //    数据库错误
            emitter.emit("false");
            console.log(err);
        }
        if(result.length==0){
          res.send(result);
          emitter.emit("false");
        }else{
          // res.end(result[]);

          res.send(result);
            // res.end("登陆成功");    //返回登录成功
        }
    })
    connection.end();    //    关闭数据库



});

router.get('/mv1', function(req, res, next) {
  //    创建数据库连接
    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"newpass",
        // port: '3306',
        database:"qqmusic"
    });

    emitter.on("ok",function(){
        return res.end("登陆成功");    //    向前台返回数据
    });

  emitter.on("false",function(){
        return res.end("登录失败");    //    向前台返回数据
  });

    connection.connect();
    if(req.query.area==="全部"){
          var sql="select * from mv";    //    在数据库里面查询用户名跟密码
    }else{
      console.log(req.query.area);
      var sql = "select * from mv where MV_area='"+req.query.area+"'";    //    在数据库里面查询用户名跟密码

    }
    connection.query(sql,function(err,result){    //    执行sql语句，并返回结果

console.log(result.length);
        if(err){
            // res.end("登录失败");    //    数据库错误
            emitter.emit("false");
            console.log(err);
        }
        if(result.length==0){
          res.send(result);
          emitter.emit("false");
        }else{
          // res.end(result[]);
          res.send(result);
            // res.end("登陆成功");    //返回登录成功
        }
    })
    connection.end();    //    关闭数据库



});

router.get('/mv2', function(req, res, next) {
  //    创建数据库连接
    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"newpass",
        // port: '3306',
        database:"qqmusic"
    });

    emitter.on("ok",function(){
        return res.end("登陆成功");    //    向前台返回数据
    });

  emitter.on("false",function(){
        return res.end("没有");    //    向前台返回数据
  });

    connection.connect();
    console.log(req.query.area);
    console.log(req.query.type);
    console.log(req.query.area==="全部");
    if(req.query.area==="全部"){
      var sql = "select * from mv where MV_type='"+req.query.type+"'";
    }
    else{
    var sql="select * from mv where MV_area='"+req.query.area+"' and MV_type='"+req.query.type+"'";    //    在数据库里面查询用户名跟密码
  }
    // if(req.query.Language==="全部"){
    //       var sql="select * from album";    //    在数据库里面查询用户名跟密码

    //   // var sql="select * from album where Album_name='80/90年代迪斯科舞曲精选集'";    //    在数据库里面查询用户名跟密码
    // }
    connection.query(sql,function(err,result){    //    执行sql语句，并返回结果

console.log(result.length);
        if(err){
            // res.end("登录失败");    //    数据库错误
            emitter.emit("false");
            console.log(err);
        }
        if(result.length==0){
          res.send(result);
          emitter.emit("false");
        }else{
          // res.end(result[]);
          res.send(result);
            // res.end("登陆成功");    //返回登录成功
        }
    })
    connection.end();    //    关闭数据库
});

router.get('/mv3', function(req, res, next) {
  //    创建数据库连接
    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"newpass",
        // port: '3306',
        database:"qqmusic"
    });

    emitter.on("ok",function(){
        return res.end("登陆成功");    //    向前台返回数据
    });

  emitter.on("false",function(){
        return res.end("没有");    //    向前台返回数据
  });

    connection.connect();
    console.log(req.query.area);
    console.log(req.query.type);
    console.log(req.query.area==="全部");
    if(req.query.area==="全部"){
      var sql = "select * from mv where MV_type='"+req.query.type+"'";
    }
    else{
      var sql="select * from mv where MV_area='"+req.query.area+"' and MV_type='"+req.query.type+"'";    //    在数据库里面查询用户名跟密码
    }
    if(req.query.area==="全部"){
      if(req.query.type==="全部"){
        if (req.query.year==="全部") {
          var sql = "select * from mv";
        }
        else{
          var sql = "select * from mv where MV_year='"+req.query.year+"'";
        } 
      }
      else{
        var sql = "select *from mv where MV_type='"+req.query.type+"'and MV_year='"+req.query.year+"'";
      } 
    }
    else{
      var sql = "select *from mv where MV_type='"+req.query.type+"'and MV_year='"+req.query.year+"'"+"and MV_area='"+req.query.area+"'";
    }

    connection.query(sql,function(err,result){    //    执行sql语句，并返回结果

    console.log(result.length);
        if(err){
            // res.end("登录失败");    //    数据库错误
            emitter.emit("false");
            console.log(err);
        }
        if(result.length==0){
          res.send(result);
          emitter.emit("false");
        }else{
          // res.end(result[]);
          res.send(result);
            // res.end("登陆成功");    //返回登录成功
        }
    })
    connection.end();    //    关闭数据库



});

router.get('/help', function(req, res, next) {
	// res.render('error.html', { title: 'Express' });
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;
  console.log('session1:'+loginUser);
  console.log('session2:'+isLogined);


  res.render('zhuye.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});


//sw
router.get('/paihang', function(req, res, next) {
  // res.render('error.html', { title: 'Express' });
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;
  console.log('session1:'+loginUser);
  console.log('session2:'+isLogined);


  res.render('charts0.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});
router.get('/charts1', function(req, res, next) {
  // res.render('error.html', { title: 'Express' });
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;
  console.log('session1:'+loginUser);
  console.log('session2:'+isLogined);


  res.render('charts1.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});
router.get('/charts2', function(req, res, next) {
  // res.render('error.html', { title: 'Express' });
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;
  console.log('session1:'+loginUser);
  console.log('session2:'+isLogined);


  res.render('charts2.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});
router.get('/charts3', function(req, res, next) {
  // res.render('error.html', { title: 'Express' });
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;
  console.log('session1:'+loginUser);
  console.log('session2:'+isLogined);


  res.render('charts3.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});


// router.get('/', function(req, res, next) {
//   res.render('login.html', { title: 'Express' });
// });
router.get('/',function(req,res,next){
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('login.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
});
router.get('/mymusic',function(req,res,next){
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('ilike.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
});



router.get('/logout', function(req, res, next){
    // 备注：这里用的 session-file-store 在destroy 方法里，并没有销毁cookie
    // 所以客户端的 cookie 还是存在，导致的问题 --> 退出登陆后，服务端检测到cookie
    // 然后去查找对应的 session 文件，报错
    // session-file-store 本身的bug    

    req.session.destroy(function(err) {
        if(err){
            res.json({ret_code: 2, ret_msg: '退出登录失败'});
            return;
        }
        
        // req.session.loginUser = false;
        res.clearCookie("identityKey");
        res.redirect('/');
    });
});


router.get('/zhuanji', function(req, res, next) {
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('专辑.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});




//index
router.get('/cd', function(req, res, next) {
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('cd.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});
router.get('/song', function(req, res, next) {
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('song.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});
router.get('/songplay', function(req, res, next) {
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('songplay.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});
router.get('/MVPLAY', function(req, res, next) {
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('MVPLAY.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});
router.get('/singer22', function(req, res, next) {
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('singer2.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});


router.get('/diantai', function(req, res, next) {
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('电台.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
  // res.send('helpPage');
});

router.get('/singer', function(req, res, next) {
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('Singer.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
});
router.get('/MV', function(req, res, next) {
  var sess = req.session;
  var loginUser = sess.loginUser;
  var isLogined = !!loginUser;

   res.render('MV.html', {
        isLogined: isLogined,
        name: loginUser || ''
    });
});



router.get("/login2",function(req,res,next){    //    获取登录传过来的值
    //    创建数据库连接
    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"newpass",
        // port: '3306',
        database:"qqmusic"
    });
//     var connection = mysql.createConnection({
//        host     : ‘localhost’,
// database: ‘qqmusic’,
// 	  port: ‘3306’,
// user     : ‘root’,
// password : ‘newpass’,
// });

  emitter.on("ok",function(){
        return res.end("denglu成功");    //    向前台返回数据
  });

  emitter.on("false",function(){
        return res.end("denglushibai");    //    向前台返回数据
  });
    connection.connect();
    var sql="select * from user where number='"+req.query.username+"' and password='"+req.query.passwd+"'";    //    在数据库里面查询用户名跟密码
    connection.query(sql,function(err,result){    //    执行sql语句，并返回结果
      if(result){
        console.log(result.length);
      }
    	
        if(err){
            // res.end("登录失败");    //    数据库错误
            emitter.emit("false");
            console.log(err);
        }
        if(result.length==0){
        	emitter.emit("false");
            // emitter.emit("false");    
            res.end("用户名密码不正确");    //    数据库里面没找到配对的内容返回参数
        }else{
        	emitter.emit("ok");
            // res.end("登陆成功");    //返回登录成功
        }
    })
    connection.end();    //    关闭数据库
});


module.exports = router;
