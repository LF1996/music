

function checkboxAll(){
    var obgCheckbox =document.getElementsByName("opration");
    //var obgForm = document.getElementsByName("form1");
    for (var i = 0; i <obgCheckbox.length; i++) {
        var x = document.getElementById("CheckboxAll") ;
        if(x.checked==true)
        {
            if (obgCheckbox[i].type == "checkbox") {
                obgCheckbox[i].checked = "checked";
            }
        }else{
            if (obgCheckbox[i].type == "checkbox") {
                obgCheckbox[i].checked = "";
            }
        }
    }
}

function BatchOpration() {
    var objCheck = document.getElementsByName("Check");
    if (objCheck[0].style.display == "none")
        for (var i = 0; i < objCheck.length; i++) {
            objCheck[i].style.display = "inline"
        }
    else
        for (var i = 0; i < objCheck.length; i++) {
            objCheck[i].style.display = "none"
        }
}

$(document).ready(function(){
    date();
});


function date(){
    var now= new Date();
    var year=now.getFullYear();
    var month=now.getMonth();
    var date=now.getDate();
//获取相应ID
    document.getElementById("today").innerHTML=year+"-"+(month+1)+"-"+date;
}

// function over(e) {
//     var objDiv=e.getElementById("Spediv");
//     objDiv.style.display="inline"
// }
//
// function out(e) {
//     var objDiv=e.getElementById("Spediv");
//     objDiv.style.display="none"
// }

// $(function(){
//
//     $('form#songlist ul').mouseover(function(){$(this).find('Spediv').style.display="inline"});
// })
//
// $(function(){
//
//     $('form#songlist ul').mouseout(function(){$(this).find('Spediv').style.display="none"});
// })

// function stopPropagation(e) {
//     if (e.stopPropagation)
//         e.stopPropagation();
//     else
//         e.cancelBubble = true;
// }
//
// $(document).bind('click',function(){
//     $('#popup').css('display','none');
// });
//
// $('#popup').bind('click',function(e){
//     stopPropagation(e);
// });

function show_regular(){
    var objDiv=document.getElementById("popup");
    objDiv.style.display="block";
}


$(document).bind('click',function(e){
    var e = e || window.event; //浏览器兼容性
    var elem = e.target || e.srcElement;
    while (elem) { //循环判断至跟节点，防止点击的是div子元素
        if (elem.id=='popup'||elem.id=='show_btn') {
            return;
        }
        elem = elem.parentNode;
    }

       $('#popup').css('display','none'); //点击的不是div或其子元素
});