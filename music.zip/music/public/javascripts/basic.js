/**
 * Created by yajia on 2017/7/16.
 */

var $ = function () {
    return new Base();
}

function Base() {

    //定义属性(数组：用来保存获取到的结点元素)
    this.elements = [];

    //定义方法

    this.getId = function (id) {
        //根据id来获取某个结点元素
        this.elements.push(document.getElementById(id));
        return this;//this表示Base对象自身
    }

    //根据标签（Tag）的名称来获取结点元素
    this.getTagName = function (tag) {
        //根据标签（Tag）的名称来获取结点元素
        var tags = document.getElementsByTagName(tag);
        for(var i = 0;i<tags.length;i++){
            this.elements.push(tags[i]);
        }
        return this;
    }

}

//通过此方法来设置html纯文本内容
//prototype：每创建一个函数都会有一个prototype属性，它表示Js中的原型
//Base.prototype.html表示向Base对象中添加一个原型方法
Base.prototype.html = function (str) {
    for(var i = 0;i<this.elements.length;i++){
        this.elements[i].innerHTML = str;
    }
    return this;
}
Base.prototype.css = function (attr,value) {
    for(var i = 0;i<this.elements.length;i++){
        this.elements[i].style[attr] = value;
    }
}

Base.prototype.click = function (fn) {
    for(var i = 0;i<this.elements.length;i++){
        this.elements[i].onclick = fn;
    }
}

var bs = new Base();
bs.getId("box");
bs.html("lf");
// bs.click(cli());
var bs1 = new Base();
bs1.getTagName("p");
bs1.html("666");
var cli = function () {
    alert("this is a p label");
}
bs1.click(cli);
bs1.css("font-size",'50px');