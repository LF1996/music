// alert("asdsaalfkalskjklfsjkaf");

function box() {
    return arguments[0]+arguments[1];
}
//box();
function box1(a,b) {
    return a+b;
}
var sum = box(1,2,3);
 alert(sum);
