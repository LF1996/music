/**
 * Created by 牙牙健康白又白 on 2017/7/18.
 */
$(function () {
    $('#img1').mouseleave(function () {
        $('#span1').hide();
    });

})


$(function () {
    $('#img1').mouseenter(function () {
        $('#span1').show();
    })
    $('#span1').mouseenter(function () {
        $('#span1').show();
    })
})

$(function () {
    $('#img2').mouseleave(function () {
        $('#span2').hide();
    });

})


$(function () {
    $('#img2').mouseenter(function () {
        $('#span2').show();
    })
    $('#span2').mouseenter(function () {
        $('#span2').show();
    })
})

$(function () {
    $('#img3').mouseleave(function () {
        $('#span3').hide();
    });

})


$(function () {
    $('#img3').mouseenter(function () {
        $('#span3').show();
    })
    $('#span3').mouseenter(function () {
        $('#span3').show();
    })
})

$(function () {
    $('#img4').mouseleave(function () {
        $('#span4').hide();
    });

})


$(function () {
    $('#img4').mouseenter(function () {
        $('#span4').show();
    })
    $('#span4').mouseenter(function () {
        $('#span4').show();
    })
})

$(function () {
    $('#img5').mouseleave(function () {
        $('#span5').hide();
    });

})


$(function () {
    $('#img5').mouseenter(function () {
        $('#span5').show();
    })
    $('#span5').mouseenter(function () {
        $('#span5').show();
    })
})



//mv控制
$(function () {
    $('#img1_mv').mouseleave(function () {
        $('#span1_mv').hide();
    });

})


$(function () {
    $('#img1_mv').mouseenter(function () {
        $('#span1_mv').show();
    })
    $('#span1_mv').mouseenter(function () {
        $('#span1_mv').show();
    })
})

$(function () {
    $('#img2_mv').mouseleave(function () {
        $('#span2_mv').hide();
    });

})


$(function () {
    $('#img2_mv').mouseenter(function () {
        $('#span2_mv').show();
    })
    $('#span2_mv').mouseenter(function () {
        $('#span2_mv').show();
    })
})

$(function () {
    $('#img3_mv').mouseleave(function () {
        $('#span3_mv').hide();
    });

})


$(function () {
    $('#img3_mv').mouseenter(function () {
        $('#span3_mv').show();
    })
    $('#span3_mv').mouseenter(function () {
        $('#span3_mv').show();
    })
})

$(function () {
    $('#img4_mv').mouseleave(function () {
        $('#span4_mv').hide();
    });

})


$(function () {
    $('#img4_mv').mouseenter(function () {
        $('#span4_mv').show();
    })
    $('#span4_mv').mouseenter(function () {
        $('#span4_mv').show();
    })
})

$(function () {
    $('#img5_mv').mouseleave(function () {
        $('#span5_mv').hide();
    });

})


$(function () {
    $('#img5_mv').mouseenter(function () {
        $('#span5_mv').show();
    })
    $('#span5_mv').mouseenter(function () {
        $('#span5_mv').show();
    })
})

function getStyle(obj,name)
{
    if(obj.currentStyle)
    {
        return obj.currentStyle[name];
    }

    else
    {
        return getComputedStyle(obj,false)[name];
    }
}

function startMove(obj,json,fnEnd)
{
    clearInterval(obj.timer);
    obj.timer=setInterval(function()
    {
        var bStop=true;
        for(var attr in json)
        {
            var cur=0;

            if(attr=='opacity')
            {
                cur=Math.round(parseFloat(getStyle(obj,attr))*100);
            }
            else
            {
                cur=parseInt(getStyle(obj,attr));
            }

            var  speed=(json[attr]-cur)/6;
            speed=speed>0?Math.ceil(speed):Math.floor(speed);

            if(cur!=json[attr]) bStop=false;

            if(attr=='opacity')
            {
                obj.style.filter='alpha(opacity:'+(cur+speed)+')';
                obj.style.opacity=(cur+speed)/100;
            }
            else
            {
                obj.style[attr]=cur+speed+'px';
            }
        }

        if(bStop)
        {
            clearInterval(obj.timer);
            if(fnEnd) fnEnd();
        }

    },30)

}


window.onload=function()
{
    var oPic=document.getElementById('pic');
    var oPrev=getByClass(oPic,'prev')[0];
    var oNext=getByClass(oPic,'next')[0];

    var aLi=oPic.getElementsByTagName('li');

    var arr=[];

    for(var i=0;i<aLi.length;i++)
    {
        var oImg=aLi[i].getElementsByTagName('img')[0];

        arr.push([parseInt(getStyle(aLi[i],'left')),parseInt(getStyle(aLi[i],'top')),
            getStyle(aLi[i],'zIndex'),oImg.width,parseFloat(getStyle(aLi[i],'opacity')*100)]);
    }


    oPrev.onclick=function()
    {
        arr.push(arr[0]);
        arr.shift();
        for(var i=0;i<aLi.length;i++)
        {
            var oImg=aLi[i].getElementsByTagName('img')[0];

            aLi[i].style.zIndex=arr[i][2];
            startMove(aLi[i],{left:arr[i][0],top:arr[i][1],opacity:arr[i][4]});
            startMove(oImg,{width:arr[i][3]});
        }

    }

    oNext.onclick=function()
    {
        arr.unshift(arr[arr.length-1]);
        arr.pop();
        for(var i=0;i<aLi.length;i++)
        {
            var oImg=aLi[i].getElementsByTagName('img')[0];

            aLi[i].style.zIndex=arr[i][2];
            startMove(aLi[i],{left:arr[i][0],top:arr[i][1],opacity:arr[i][4]});
            startMove(oImg,{width:arr[i][3]});
        }
    }

    function getStyle(obj,name)
    {
        if(obj.currentStyle){ return obj.currentStyle[name]; }
        else{ return getComputedStyle(obj,false)[name]; }
    }
}

function getByClass(oParent,sClass)
{
    var aResult=[];
    var aEle=oParent.getElementsByTagName('*');

    for(var i=0;i<aEle.length;i++)
    {
        if(aEle[i].className==sClass)
        {
            aResult.push(aEle[i]);
        }
    }
    return aResult;
}

